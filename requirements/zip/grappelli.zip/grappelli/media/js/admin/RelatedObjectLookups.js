// dropped
// use grappelli.RelatedObjectLookups.js instead
// kept this file to prevent 404